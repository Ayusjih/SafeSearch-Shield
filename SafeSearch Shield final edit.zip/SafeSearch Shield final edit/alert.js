let ip_address;
var initialUrl;
let toggle = 0; // Initialize toggle to 0

var word ;

//----------------------------------------------------------------------------------

// Confirmation dialog logic
if (confirm('Irrelevant search, do you wish to continue?')) {
    toggle = 1; // Update toggle to 1 if user clicks OK for get to user url
    console.log("Toggle set to:", toggle);

    // Notify background.js of the toggle value
    chrome.runtime.sendMessage({ action: "updateToggle", toggle });

    fetchIpAddress()
        .then(result => {3
            if (result) {
                console.log(result);
            }
        })
        .catch(error => {
            console.error('Error fetching IP address:', error);
        })
        .finally(() => {
            window.location.href = initialUrl; // Redirect to initial URL after fetch
        });
} else {
    console.log("Toggle remains:", toggle); // Toggle stays 0 if user clicks Cancel
    // Notify background.js of the toggle value
    chrome.runtime.sendMessage({ action: "updateToggle", toggle });

    window.location.href = 'https://www.google.com'; // Redirect to Google
}


//------------------------------------------------------------------------------------------------------------------------------------------------------

// Request the variable from background.js
chrome.runtime.sendMessage({ action: "getVariable" }, (response) => {
    if (response && response.data) {
        initialUrl = response.data;
    } else {
        console.error("Failed to get the variable from background.js");
    }
});
// Request the variable from background.js
chrome.runtime.sendMessage({ action: "getVariabl" }, (response) => {
    if (response && response.variable) {
        word = response.variable;
    } else {
        console.error("Failed to get the variable from background.js");
    }
});


//--------------------------------------------------------------------------------------------------------------------------------------------------------

const API_KEY = 'patvAOxoSd15KysIK.57cee6fb3fea6a06e73f3da81bf868c02624cc2f02af4ac12edec436aafe10bc'; // Replace with your Airtable API Key
const BASE_ID = 'app6NIjzMgElahvq8'; // Base ID extracted from your base link
const TABLE_NAME = 'ip_logger'; // Replace with your actual table name

// Function to fetch public IP address
async function fetchIpAddress() {
    try {
        const response = await fetch('https://api64.ipify.org?format=json');
        const data = await response.json();

        const ipAddress = data.ip;
        console.log('Fetched IP Address:', ipAddress);

        // saveToFile(ip_address, 'ip_address.txt');

        // Write IP to Airtable
        await writeIpToAirtable(ipAddress);
    } catch (error) {
        console.error('Error fetching IP address:', error);
    }
}
 


//--------------------------------------------------------------------------------------------------------------------------------------------------
// Function to write IP address to Airtable

async function writeIpToAirtable(ipAddress) {
    const url = `https://api.airtable.com/v0/${BASE_ID}/${TABLE_NAME}`;
    const record = {
        records: [
            {
                fields: {
                    ip: ipAddress,
                    timeStamp: getIndianTimeStamp(), // Save the timestamp in IST
                    searched_word: word
                }
            }
        ]
    };

    try {
        const response = await fetch(url, {
            method: 'POST',
            headers: {
                Authorization: `Bearer ${API_KEY}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(record)
        });

        const responseBody = await response.json();

        if (response.ok) {
            console.log('IP Address successfully written to Airtable:', responseBody);
        } else {
            console.error('Error writing IP to Airtable:', responseBody);
        }
    } catch (error) {
        console.error('Error:', error);
    }
}




//to get indian time-----------------------------------------------------------------------------------------------------------------------------------
function getIndianTimeStamp() {
    const date = new Date();

    // Use Intl.DateTimeFormat to convert the date to IST (Indian Standard Time)
    const options = {
        timeZone: 'Asia/Kolkata', // India Standard Time (IST)
        year: 'numeric',
        month: '2-digit',
        day: '2-digit',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: false, // Use 24-hour time format
    };

    // Format the date to IST
    const formatter = new Intl.DateTimeFormat('en-IN', options);
    const formattedDate = formatter.format(date);

    // Manually construct the ISO string format (yyyy-MM-ddTHH:mm:ss) from the formatted date
    const [datePart, timePart] = formattedDate.split(', ');
    const isoFormatted = `${'  date: '}${datePart.replace(/\//g, '/')}${' ,  time: '}${timePart.replace(/:/g, ':')}`;

    return isoFormatted;
}


